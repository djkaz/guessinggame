﻿using System;

namespace GuessingGame
{
    class Program
    {
        static void Main(string[] args)
        {
            string secretWord = "giraffe";
            string guess = "";

            while (guess!=secretWord) {

                Console.Write("Enter guess: ");
                guess = Console.ReadLine();

            }
            Console.WriteLine("You Win!");
            Console.ReadLine();

        }
    }
}
